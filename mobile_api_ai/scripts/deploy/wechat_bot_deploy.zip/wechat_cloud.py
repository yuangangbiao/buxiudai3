# -*- coding: utf-8 -*-
"""
云端服务 - 微信回调接收 + 消息队列 + 主动发送
混合模式云端部分

启动命令: python wechat_cloud.py
"""
import os
import sys
import logging
import json
import time
import threading
from datetime import datetime
from collections import deque
from functools import wraps

import requests
from flask import Flask, request, jsonify
from logging_setup import setup_daily_logger, cleanup_old_logs, read_log

try:
    from dotenv import load_dotenv
    if getattr(sys, 'frozen', False):
        env_path = os.path.join(os.path.dirname(sys.executable), '.env')
    else:
        env_path = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), '.env')
    load_dotenv(env_path)
except ImportError:
    pass

setup_daily_logger('wechat_cloud')
logger = logging.getLogger(__name__)

# ============== 云端备份存储（仅归档，不参与业务） ==============
from cloud_backup import (
    init_db, save_incoming_message, save_outgoing_message,
    save_callback_log, save_queue_backup, get_backup_stats
)
_init_ok = init_db()

app = Flask(__name__)

# ============== 配置 ==============
API_KEY = os.getenv('WECHAT_CLOUD_API_KEY', '')

# ============== 消息队列（线程安全） ==============
message_queue = deque(maxlen=int(os.getenv('WECHAT_CLOUD_QUEUE_MAXLEN', '5000')))
queue_lock = threading.Lock()

# ============== 工具函数 ==============
def require_api_key(f):
    """API Key验证装饰器"""
    @wraps(f)
    def decorated(*args, **kwargs):
        key = request.headers.get('X-API-Key') or request.args.get('api_key')
        if key != API_KEY:
            logger.warning(f'[认证] 未授权访问 from {request.remote_addr}')
            return jsonify({'code': 403, 'message': 'Unauthorized'}), 403
        return f(*args, **kwargs)
    return decorated

# ============== 微信回调验证接口 ==============
@app.route('/api/wechat/hook', methods=['GET', 'POST'])
def wechat_hook():
    if request.method == 'GET':
        return wechat_verify()
    else:
        return wechat_callback()

def wechat_verify():
    msg_signature = request.args.get('msg_signature', '')
    timestamp = request.args.get('timestamp', '')
    nonce = request.args.get('nonce', '')
    echostr = request.args.get('echostr', '')

    logger.info(f'[验证] 收到微信验证请求: msg_signature={msg_signature}, echostr={echostr[:20]}...')

    if not echostr:
        logger.warning('[验证] 缺少echostr参数')
        return 'error', 400

    try:
        from wechat_app_bot import WeChatAppBot
        bot = WeChatAppBot(
            os.getenv('WECHAT_CORP_ID', ''),
            os.getenv('WECHAT_AGENT_ID', ''),
            os.getenv('WECHAT_SECRET', '')
        )
        decrypted = bot._decrypt_message(
            echostr,
            token=os.getenv('WECHAT_TOKEN', ''),
            aes_key=os.getenv('WECHAT_AES_KEY', ''),
            msg_signature=msg_signature,
            timestamp=timestamp,
            nonce=nonce
        )
        logger.info(f'[验证] 解密echostr成功')
        return decrypted, 200
    except Exception as e:
        logger.error(f'[验证] 处理异常: {e}')
        return 'error', 400


# ============== 微信回调接口 ==============
@app.route('/api/wechat/callback', methods=['POST'])
def wechat_callback():
    """接收微信回调"""
    try:
        xml_data = request.data
        msg_signature = request.args.get('msg_signature', '')
        timestamp = request.args.get('timestamp', '')
        nonce = request.args.get('nonce', '')

        logger.info(f'[回调] 收到微信回调: {xml_data[:200]}')

        from wechat_app_bot import WeChatAppBot
        bot = WeChatAppBot(
            os.getenv('WECHAT_CORP_ID', ''),
            os.getenv('WECHAT_AGENT_ID', ''),
            os.getenv('WECHAT_SECRET', '')
        )
        result = bot.process_callback(
            xml_data,
            token=os.getenv('WECHAT_TOKEN', ''),
            aes_key=os.getenv('WECHAT_AES_KEY', ''),
            msg_signature=msg_signature,
            timestamp=timestamp,
            nonce=nonce
        )

        logger.info(f'[回调] 处理结果: {result}')

        # === 备份：回调日志和入站消息 ===
        save_callback_log(msg_signature, timestamp, nonce, str(result),
                          xml_data.decode('utf-8', errors='ignore')[:3000])
        save_incoming_message(user_id='', content='(回调已处理)',
                              xml_raw=xml_data.decode('utf-8', errors='ignore')[:3000],
                              msg_signature=msg_signature)

        return 'success', 200
    except Exception as e:
        logger.error(f'[回调] 处理异常: {e}')
        save_callback_log('', '', '', f'error:{e}', '')
        return 'error', 500

# ============== 消息队列接口 ==============
@app.route('/api/queue/push', methods=['POST'])
@require_api_key
def push_message():
    """推送消息到队列（供本地客户端调用）"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'code': 400, 'message': 'Empty data'}), 400

        with queue_lock:
            message_queue.append({
                'data': data,
                'timestamp': datetime.now().isoformat()
            })

        logger.info(f'[队列] 收到消息: {data.get("type", "unknown")}')

        # === 备份：队列推送数据 ===
        save_queue_backup(data)

        return jsonify({'code': 0, 'message': 'OK', 'queue_size': len(message_queue)})
    except Exception as e:
        logger.error(f'[队列] 推送异常: {e}')
        return jsonify({'code': 500, 'message': str(e)}), 500

@app.route('/api/queue/poll', methods=['GET'])
@require_api_key
def poll_messages():
    """拉取消息（供本地客户端调用）"""
    try:
        limit = int(request.args.get('limit', 10))
        messages = []

        with queue_lock:
            for _ in range(min(limit, len(message_queue))):
                if message_queue:
                    messages.append(message_queue.popleft())

        logger.info(f'[轮询] 拉取消息: {len(messages)}条')
        return jsonify({
            'code': 0,
            'messages': messages,
            'count': len(messages)
        })
    except Exception as e:
        logger.error(f'[轮询] 异常: {e}')
        return jsonify({'code': 500, 'message': str(e)}), 500

@app.route('/api/queue/status', methods=['GET'])
@require_api_key
def queue_status():
    """获取队列状态"""
    with queue_lock:
        return jsonify({
            'code': 0,
            'queue_size': len(message_queue),
            'max_size': message_queue.maxlen
        })

# ============== 主动发送接口 ==============
@app.route('/api/wechat/send', methods=['POST'])
@require_api_key
def send_wechat_message():
    """主动发送微信消息"""
    try:
        data = request.get_json()
        to_user = data.get('to_user')
        content = data.get('content')
        msg_type = data.get('msg_type', 'text')

        if not to_user or not content:
            return jsonify({'code': 400, 'message': 'Missing params'}), 400

        from wechat_app_bot import WeChatAppBot
        bot = WeChatAppBot(
            os.getenv('WECHAT_CORP_ID', ''),
            os.getenv('WECHAT_AGENT_ID', ''),
            os.getenv('WECHAT_SECRET', '')
        )
        result = bot.send_text(to_user, content)

        logger.info(f'[发送] 发送消息给 {to_user}: {content[:50]}')

        # === 备份：出站消息 ===
        save_outgoing_message(to_user, content[:500], msg_type=msg_type)

        return jsonify({'code': 0, 'result': result})
    except Exception as e:
        logger.error(f'[发送] 异常: {e}')
        return jsonify({'code': 500, 'message': str(e)}), 500

@app.route('/api/wechat/send_text', methods=['POST'])
@require_api_key
def send_text():
    """发送文本消息（兼容旧接口）"""
    return send_wechat_message()


# ============== 云端代理转发 ==============
@app.route('/api/wechat/proxy_send', methods=['POST'])
@require_api_key
def proxy_send():
    """
    云端代理转发接口

    接收本地 GroupBot 的代理请求，将消息转发到企业微信 Webhook。
    本地运行时 GroupBot 检测到 WECHAT_CLOUD_HOST 非空，将消息转发至此端点。
    云服务器运行时 WECHAT_CLOUD_HOST 为空，GroupBot 直接调用 Webhook。

    请求体:
    {
        "_webhook_url": "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=xxx",
        "_api_key": "Wk9Q-8X7Z-3K2M-5P6L",
        "msgtype": "text",
        "text": {"content": "hello"}
    }

    Returns:
        企业微信 Webhook 的原始响应
    """
    try:
        data = request.get_json(silent=True) or {}
        webhook_url = data.pop('_webhook_url', '')
        _ = data.pop('_api_key', '')

        if not webhook_url:
            logger.warning("[Proxy] 缺少 _webhook_url")
            return jsonify({'errcode': 400, 'errmsg': '缺少 _webhook_url'}), 400

        if 'msgtype' not in data:
            logger.warning("[Proxy] 缺少 msgtype 字段")
            return jsonify({'errcode': 400, 'errmsg': '缺少 msgtype 字段'}), 400

        logger.info(f"[Proxy] 转发消息到企业微信: msgtype={data.get('msgtype')}")

        resp = requests.post(
            webhook_url,
            json=data,
            timeout=10,
            headers={'Content-Type': 'application/json'}
        )

        result = resp.json()
        logger.info(f"[Proxy] 企业微信响应: errcode={result.get('errcode')}")

        return jsonify(result)

    except requests.exceptions.Timeout:
        logger.error("[Proxy] 转发请求超时")
        return jsonify({'errcode': 408, 'errmsg': '请求超时'}), 408
    except requests.exceptions.RequestException as e:
        logger.error(f"[Proxy] 转发请求异常: {e}")
        return jsonify({'errcode': 502, 'errmsg': f'转发失败: {str(e)}'}), 502
    except Exception as e:
        logger.error(f"[Proxy] 未知异常: {e}")
        return jsonify({'errcode': 500, 'errmsg': str(e)}), 500


# ============== 日志查看接口 ==============
@app.route('/logs', methods=['GET'])
@require_api_key
def view_logs():
    """查看日志（日日志系统）"""
    try:
        date_str = request.args.get('date')
        level = request.args.get('level')
        tail = int(request.args.get('tail', 100))

        content = read_log('wechat_cloud', date_str=date_str, tail_lines=tail, level=level)
        lines = content.split('\n') if content else []

        return jsonify({
            'code': 0,
            'total': len(lines),
            'logs': lines[-tail:]
        })
    except Exception as e:
        logger.error(f"[Logs] 读取异常: {e}")
        return jsonify({'code': 500, 'message': str(e)}), 500

# ============== 备份存储状态 ==============
@app.route('/api/backup/status', methods=['GET'])
@require_api_key
def backup_status():
    """查看备份存储状态（仅管理查阅，不参与业务）"""
    stats = get_backup_stats()
    return jsonify({
        'code': 0,
        'backup_enabled': _init_ok,
        'stats': stats
    })

# ============== 企业微信通讯录代理接口 ==============
@app.route('/api/wechat/users', methods=['GET'])
@app.route('/api/wechat/contacts', methods=['GET'])
@require_api_key
def get_wechat_contacts():
    """
    获取企业微信通讯录（云端代理）

    云端获取通讯录可以解决IP白名单限制问题

    Returns:
        {
            "code": 0,
            "users": [
                {"userid": "xxx", "name": "张三", "department": [1], "position": "员工"},
                ...
            ],
            "departments": [...],
            "count": 10
        }
    """
    try:
        from wechat_app_bot import WeChatAppBot
        bot = WeChatAppBot(
            os.getenv('WECHAT_CORP_ID', ''),
            os.getenv('WECHAT_AGENT_ID', ''),
            os.getenv('WECHAT_SECRET', '')
        )

        token = bot.get_access_token()
        if not token:
            return jsonify({'code': 500, 'message': '获取access_token失败'}), 500

        users = []
        departments = []

        dept_resp = requests.get(f'https://qyapi.weixin.qq.com/cgi-bin/department/list?access_token={token}', timeout=10)
        dept_result = dept_resp.json()
        if dept_result.get('errcode') == 0:
            departments = dept_result.get('department', [])

        for dept in departments:
            dept_id = dept.get('id')
            users_resp = requests.get(
                f'https://qyapi.weixin.qq.com/cgi-bin/user/simplelist?access_token={token}&department_id={dept_id}&fetch_child=1',
                timeout=10
            )
            users_result = users_resp.json()
            if users_result.get('errcode') == 0:
                for user in users_result.get('userlist', []):
                    user['department_name'] = dept.get('name', '')
                    users.append(user)

        logger.info(f'[通讯录] 获取到 {len(users)} 名用户，{len(departments)} 个部门')

        return jsonify({
            'code': 0,
            'users': users,
            'departments': departments,
            'count': len(users)
        })

    except Exception as e:
        logger.error(f'[通讯录] 获取异常: {e}')
        return jsonify({'code': 500, 'message': str(e)}), 500

@app.route('/api/wechat/user/<user_id>', methods=['GET'])
@require_api_key
def get_wechat_user(user_id):
    """
    获取单个微信用户信息（云端代理）

    Args:
        user_id: 企业微信UserID

    Returns:
        {
            "code": 0,
            "user": {"userid": "xxx", "name": "张三", ...}
        }
    """
    try:
        from wechat_app_bot import WeChatAppBot
        bot = WeChatAppBot(
            os.getenv('WECHAT_CORP_ID', ''),
            os.getenv('WECHAT_AGENT_ID', ''),
            os.getenv('WECHAT_SECRET', '')
        )

        user_info = bot.get_user_info(user_id)
        if user_info:
            return jsonify({
                'code': 0,
                'user': user_info
            })
        else:
            return jsonify({'code': 404, 'message': f'未找到用户 {user_id}'}), 404

    except Exception as e:
        logger.error(f'[用户] 获取异常: {e}')
        return jsonify({'code': 500, 'message': str(e)}), 500

@app.route('/api/wechat/user/<user_id>/name', methods=['GET'])
@require_api_key
def get_wechat_user_name(user_id):
    """
    获取微信用户名称（云端代理，快速获取姓名）

    这是一个轻量级接口，专门用于根据user_id获取用户姓名

    Args:
        user_id: 企业微信UserID

    Returns:
        {
            "code": 0,
            "userid": "xxx",
            "name": "张三"
        }
    """
    try:
        from wechat_app_bot import WeChatAppBot
        bot = WeChatAppBot(
            os.getenv('WECHAT_CORP_ID', ''),
            os.getenv('WECHAT_AGENT_ID', ''),
            os.getenv('WECHAT_SECRET', '')
        )

        user_info = bot.get_user_info(user_id)
        if user_info:
            return jsonify({
                'code': 0,
                'userid': user_id,
                'name': user_info.get('name', user_id)
            })
        else:
            return jsonify({
                'code': 0,
                'userid': user_id,
                'name': user_id
            })

    except Exception as e:
        logger.error(f'[用户名] 获取异常: {e}')
        return jsonify({'code': 0, 'userid': user_id, 'name': user_id})


# ============== 健康检查 ==============
@app.route('/health', methods=['GET'])
def health_check():
    """健康检查"""
    return jsonify({'status': 'ok', 'time': datetime.now().isoformat()})

# ============== 启动 ==============

if __name__ == '__main__':
    from config import Config
    cleanup_old_logs()
    logger.info('=' * 50)
    logger.info('云端微信服务 - 混合模式')
    logger.info('=' * 50)
    logger.info(f'API Key 已配置: {bool(API_KEY)}')
    logger.info(f'日志目录: {Config.LOG_DIR}/wechat_cloud/')
    logger.info(f'备份存储: {"已启用" if _init_ok else "未启用"}')
    logger.info('=' * 50)

    ssl_context = None
    cert_file = 'ssl/cert.pem'
    key_file = 'ssl/key.pem'
    if os.path.exists(cert_file) and os.path.exists(key_file):
        ssl_context = (cert_file, key_file)
        logger.info('SSL: 已启用')
    else:
        logger.warning('SSL: 未配置（生产环境需要配置）')

    port = int(os.getenv('FLASK_PORT', os.getenv('PORT', 5006)))

    from werkzeug.serving import make_server
    import socket
    server = make_server('0.0.0.0', port, app, threaded=True)
    server.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    logger.info(f'服务启动: 0.0.0.0:{port}')
    server.serve_forever()
