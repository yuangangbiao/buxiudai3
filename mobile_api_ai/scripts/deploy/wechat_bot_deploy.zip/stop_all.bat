@echo off
chcp 65001 >nul
echo ========================================
echo  停止所有服务
echo ========================================
cd /d "%~dp0"

python -c "
import psutil, socket
ports = {5002: '容器中心', 5003: '微信服务', 5006: '云端服务'}
for conn in psutil.net_connections():
    if conn.status == 'LISTEN' and conn.laddr.port in ports:
        try:
            proc = psutil.Process(conn.pid)
            proc.terminate()
            print(f'已停止 {ports[conn.laddr.port]} (PID {conn.pid})')
        except:
            pass
" 2>nul

echo 所有服务已停止
pause
