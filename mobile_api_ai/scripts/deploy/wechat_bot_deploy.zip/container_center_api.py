# -*- coding: utf-8 -*-
"""
容器中心API服务器
基于container_center_v5的API服务器
"""
import os
import json
import logging
import time
import threading
from datetime import datetime, timedelta

import jwt
from flask import Flask, request, jsonify
from flask_cors import CORS

logger = logging.getLogger(__name__)
from dotenv import load_dotenv
from config import Config

from container_center_v5 import ContainerCenter, DataStatus
from integration.desktop_callback import desktop_callback_manager

# 服务端增强模块
from modules.api_signature import require_signature, init_signature_validator
from modules.health_checker import DetailedHealthChecker as HealthChecker
from modules.deployment_manager import DeploymentManager
from modules.enhanced_audit_logger import EnhancedAuditLogger
from modules.enhanced_backup import EnhancedBackupManager
from data_integrity import DataIntegrity
from data_boundary import DataBoundary, data_boundary as global_data_boundary
from clock_sync import ClockSync, clock_sync as global_clock_sync

app = Flask(__name__)
CORS(app)

# 加载配置
load_dotenv()
SECRET_KEY = os.getenv('JWT_SECRET_KEY', '')

# 初始化容器中心
# 优先级：CONTAINER_DB_PATH 环境变量 > 项目目录下的 wechat_container.db
# 使用与主软件相同的数据库文件，确保数据同步
_project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_env_db_path = os.getenv('CONTAINER_DB_PATH', '').strip()
if _env_db_path:
    _container_db_path = os.path.abspath(_env_db_path)
    logger.info(f'[容器中心API] 使用环境变量数据库路径: {_container_db_path}')
else:
    _container_db_path = os.path.join(_project_root, 'mobile_api_ai', 'wechat_container.db')
container_center = ContainerCenter({
    'type': 'sqlite',
    'db_path': _container_db_path
})

# 初始化API签名校验器
api_secret_key = os.getenv('API_SECRET_KEY', '')
if api_secret_key:
    init_signature_validator()
    logger.info("API签名校验器已初始化")
else:
    logger.warning("API_SECRET_KEY 未设置，API签名验证已禁用")

# ──────────────────────────────────────────────
# 服务端增强模块初始化
# ──────────────────────────────────────────────
_server_health_checker = None
_server_deployment_manager = None
_server_audit_logger = None
_server_backup_manager = None
_server_clock_sync = global_clock_sync

try:
    _redis_for_server = None
    _rh = os.getenv('REDIS_HOST', '')
    if _rh:
        import redis as _r
        _redis_for_server = _r.Redis(
            host=_rh, port=int(os.getenv('REDIS_PORT', '6379')),
            decode_responses=True, socket_connect_timeout=5
        )
except Exception as e:
            logger.debug(f"Redis 连接失败（可选，不影响核心功能）: {e}")
            _redis_for_server = None

try:
    _server_health_checker = HealthChecker(
        redis_client=_redis_for_server,
        es_hosts=os.environ.get('ES_HOSTS', '').split(',') or None
    )
    logger.info("✓ 服务端健康检查器初始化完成")
except Exception as e:
    logger.warning(f"✗ 服务端健康检查器初始化失败: {e}")

try:
    _server_deployment_manager = DeploymentManager(
        backup_dir=os.environ.get('DEPLOY_BACKUP_DIR', '_backup'),
        config_dir=os.environ.get('CONFIG_DIR', '_config'),
        deploy_dir=os.environ.get('DEPLOY_DIR', '_deploy')
    )
    logger.info("✓ 服务端部署管理器初始化完成")
except Exception as e:
    logger.warning(f"✗ 服务端部署管理器初始化失败: {e}")

try:
    _server_audit_logger = EnhancedAuditLogger(
        es_hosts=os.environ.get('ES_HOSTS', 'localhost:9200').split(','),
        redis_client=_redis_for_server
    )
    logger.info("✓ 服务端审计日志模块初始化完成")
except Exception as e:
    logger.warning(f"✗ 服务端审计日志模块初始化失败: {e}")

try:
    _server_backup_manager = EnhancedBackupManager(
        backup_dir=os.environ.get('ENHANCED_BACKUP_DIR'),
        redis_password=os.environ.get('REDIS_PASSWORD')
    )
    logger.info("✓ 服务端增强备份模块初始化完成")
except Exception as e:
    logger.warning(f"✗ 服务端增强备份模块初始化失败: {e}")

logger.info("✓ 服务端时钟同步已就绪")
logger.info(
    f"  服务端增强模块: "
    f"健康检查={'✓' if _server_health_checker else '✗'}, "
    f"部署管理={'✓' if _server_deployment_manager else '✗'}, "
    f"审计日志={'✓' if _server_audit_logger else '✗'}, "
    f"增强备份={'✓' if _server_backup_manager else '✗'}"
)

# 配置版本管理（文件存储）
CONFIG_STORAGE_PATH = os.path.join(os.path.dirname(__file__), 'config_versions.json')
_config_lock = threading.Lock()

def _load_config_versions():
    """加载配置版本数据"""
    import json
    if os.path.exists(CONFIG_STORAGE_PATH):
        try:
            with open(CONFIG_STORAGE_PATH, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"加载配置版本文件失败: {e}")
    return {}

def _save_config_versions(data):
    """保存配置版本数据"""
    import json
    with _config_lock:
        try:
            with open(CONFIG_STORAGE_PATH, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"保存配置版本文件失败: {e}")


# 操作员列表
OPERATORS = [
    {'operator_id': 'OP001', 'name': '张三', 'role': '工人', 'team_name': '一班', 'wechat': '@张三'},
    {'operator_id': 'OP002', 'name': '李四', 'role': '工人', 'team_name': '一班', 'wechat': '@李四'},
    {'operator_id': 'OP003', 'name': '王五', 'role': '班组长', 'team_name': '一班', 'wechat': '@王五'},
    {'operator_id': 'OP004', 'name': '赵六', 'role': '质检员', 'team_name': '质检组', 'wechat': '@赵六'},
    {'operator_id': 'MG001', 'name': '钱经理', 'role': '主管', 'team_name': '管理层', 'wechat': '@钱经理'},
    {'operator_id': 'system', 'name': '系统', 'role': '系统', 'team_name': '系统', 'wechat': '@系统'},
]

def success(data=None, message='success'):
    result = {'code': 0, 'message': message}
    if data is not None:
        result['data'] = data
    return jsonify(result)

def fail(code=1, message='操作失败'):
    return jsonify({'code': code, 'message': message})

def get_current_operator():
    """从Token获取当前操作员"""
    auth_header = request.headers.get('Authorization', '')
    if not auth_header.startswith('Bearer '):
        return None
    token = auth_header[7:]
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        return payload
    except jwt.InvalidTokenError as e:
        logger.warning(f"JWT Token验证失败: {e}")
        return None

@app.route('/health')
def health():
    """健康检查（集成服务端健康检查器）"""
    base_info = {
        'service': 'container-center-api',
        'version': '1.0',
        'time': datetime.now().isoformat(),
        'server_modules': {
            'signature_validator': bool(api_secret_key),
            'health_checker': _server_health_checker is not None,
            'deployment_manager': _server_deployment_manager is not None,
            'audit_logger': _server_audit_logger is not None,
            'backup_manager': _server_backup_manager is not None,
        }
    }
    if _server_health_checker:
        try:
            report = _server_health_checker.get_health_report(detailed=False)
            base_info['health_report'] = report
        except Exception as e:
            base_info['health_report'] = {'status': 'error', 'message': str(e)}
    return success(base_info)

@app.route('/')
def index():
    pool_status = container_center.get_pool_status()
    return success({'service': '容器中心API', 'version': '1.0', 'pool_status': pool_status})

# ──────────────────────────────────────────────
# 3.01版本兼容API端点
# ──────────────────────────────────────────────

OPERATORS = [
    {'operator_id': 'OP001', 'name': '张三', 'role': '工人', 'team_name': '一班'},
    {'operator_id': 'OP002', 'name': '李四', 'role': '工人', 'team_name': '一班'},
    {'operator_id': 'OP003', 'name': '王五', 'role': '班组长', 'team_name': '一班'},
    {'operator_id': 'OP004', 'name': '赵六', 'role': '质检员', 'team_name': '质检组'},
    {'operator_id': 'MG001', 'name': '钱经理', 'role': '主管', 'team_name': '管理层'},
    {'operator_id': 'system', 'name': '系统', 'role': '系统', 'team_name': '系统'}
]

@app.route('/api/health')
def api_health():
    """API健康检查（供3.01版本测试连接使用）"""
    return jsonify({
        'status': 'running',
        'service': 'container-api',
        'version': '3.0',
        'timestamp': datetime.utcnow().isoformat()
    })

@app.route('/api/status')
def api_status():
    """获取容器状态（供3.01版本刷新状态使用）"""
    pool_status = container_center.get_pool_status()
    return jsonify({
        'status': 'running',
        'version': '3.0',
        'service': 'container-api',
        'containers': pool_status.get('total_packages', 0),
        'active_tasks': pool_status.get('total_packages', 0),
        'pool_status': pool_status,
        'timestamp': datetime.utcnow().isoformat()
    })

@app.route('/api/operators', methods=['GET'])
def get_operators():
    """获取操作员列表（供3.01版本调用）"""
    return success(data={
        'operators': OPERATORS
    })

@app.route('/api/dispatch', methods=['POST'])
def dispatch_task():
    """发布任务到指定操作员（供3.01版本调用）"""
    data = request.get_json(force=True, silent=True) or {}

    operator_id = data.get('operator_id')
    order_no = data.get('order_no')
    process = data.get('process', data.get('process_name', ''))
    quantity = data.get('quantity', 0)
    priority = data.get('priority', 'normal')
    source = data.get('source', 'main_software')

    if not operator_id:
        return fail(code=1001, message='缺少operator_id参数')

    operator = next((op for op in OPERATORS if op['operator_id'] == operator_id), None)
    if not operator:
        return fail(code=1002, message=f'操作员 {operator_id} 不存在')

    # 使用容器中心发布任务
    try:
        pkg = container_center.collect_report(
            order_no=order_no,
            process_name=process,
            record_id=0,
            operator_id=operator_id,
            planned_qty=quantity
        )
        
        pkg.content.update({
            'work_order_no': order_no,
            'quantity': quantity,
            'priority': priority,
            'source': source
        })
        
        container_center.storage.save_package(pkg.to_dict())
        
        if operator_id and operator_id != 'OP001':
            try:
                container_center.distributor.distribute(pkg.id, operator_id)
            except Exception as e:
                logger.warning(f'[3.01对接] 任务分配时警告: {e}')

        logger.info(f"[3.01对接] 派工成功: 订单{order_no}, 工序{process}, 操作员{operator['name']}")

        return success(data={
            'task_id': pkg.id,
            'operator_id': operator_id,
            'operator_name': operator['name'],
            'order_no': order_no,
            'process': process
        })
    except Exception as e:
        logger.error(f"[3.01对接] 派工失败: {e}")
        return fail(code=500, message=f'派工失败: {str(e)}')

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json(force=True, silent=True) or {}
    operator_id = data.get('operator_id')

    operator = next((op for op in OPERATORS if op['operator_id'] == operator_id), None)
    if not operator:
        return fail(code=1002, message='操作员不存在')

    token_payload = {
        'operator_id': operator_id,
        'name': operator['name'],
        'role': operator['role'],
        'team_name': operator.get('team_name', '默认组'),
        'exp': datetime.utcnow() + timedelta(hours=24)
    }
    token = jwt.encode(token_payload, SECRET_KEY, algorithm='HS256')

    return success(data={
        'token': token,
        'operator': {
            'id': operator['operator_id'],
            'name': operator['name'],
            'role': operator['role'],
            'team_name': operator.get('team_name', '默认组')
        }
    })

@app.route('/api/auth/verify', methods=['GET'])
def verify():
    operator = get_current_operator()
    if not operator:
        return fail(code=1002, message='无效的Token')
    return success(data={'valid': True, 'operator': operator})

@app.route('/api/pool/status', methods=['GET'])
def get_pool_status():
    """获取容器池状态"""
    status = container_center.get_pool_status()
    return success(data=status)

@app.route('/api/tasks', methods=['GET'])
def get_tasks():
    """获取当前员工的任务列表"""
    operator = get_current_operator()
    if not operator:
        return fail(code=1002, message='请先登录')

    status_filter = request.args.get('status', None)
    if status_filter:
        pkg_dicts = container_center.storage.get_packages(
            status=status_filter,
            operator=operator['operator_id']
        )
    else:
        pkg_dicts = container_center.storage.get_packages(
            operator=operator['operator_id'],
            limit=100
        )

    return success(data={
        'tasks': pkg_dicts,
        'total': len(pkg_dicts)
    })

@app.route('/api/tasks/<task_id>', methods=['GET'])
def get_task(task_id):
    """获取任务详情"""
    pkg = container_center.storage.get_package(task_id)
    if not pkg:
        return fail(code=404, message='任务不存在')
    return success(data=pkg)

@app.route('/api/tasks/<task_id>/acknowledge', methods=['POST'])
def acknowledge_task(task_id):
    """确认任务接收"""
    operator = get_current_operator()
    if not operator:
        return fail(code=1002, message='请先登录')

    result = container_center.acknowledge_task(task_id, operator['operator_id'])
    if result.get('success'):
        return success(data=result, message='任务已确认')
    else:
        return fail(code=400, message=result.get('message', '确认失败'))

@app.route('/api/tasks/unacknowledged', methods=['GET'])
def get_unacknowledged_tasks():
    """获取未确认的任务"""
    operator = get_current_operator()
    if not operator:
        return fail(code=1002, message='请先登录')

    tasks = container_center.get_unacknowledged_tasks(operator['operator_id'])
    return success(data={
        'tasks': tasks,
        'total': len(tasks)
    })

@app.route('/api/tasks/<task_id>/complete', methods=['POST'])
def complete_task(task_id):
    """完成任务"""
    operator = get_current_operator()
    if not operator:
        return fail(code=1002, message='请先登录')

    data = request.get_json(force=True, silent=True) or {}
    return_data = data.get('return_data', {})

    # 数据边界校验（服务端权威校验）
    quantity = return_data.get('quantity', 0)
    is_valid, error_msg = global_data_boundary.validate_report_request(
        order_no=return_data.get('order_no', ''),
        process=return_data.get('process', ''),
        quantity=quantity,
        user_id=operator['operator_id']
    )
    if not is_valid:
        logger.warning(f"完成任务数据校验失败: {error_msg}")
        return fail(code=400, message=error_msg)

    result = container_center.receive_return(task_id, return_data)

    if result.get('success') and _server_audit_logger:
        try:
            _server_audit_logger.log(
                action='task_complete',
                operator=operator['operator_id'],
                resource=f'task/{task_id}',
                detail={'return_data': return_data}
            )
        except Exception as e:
            logger.warning(f"审计日志记录失败 (task_complete): {e}")

    return success(data=result)

def _validate_api_key():
    """验证API Key（用于主软件等简单集成）"""
    api_key = request.headers.get('X-API-Key')
    if not api_key:
        return False, "缺少 X-API-Key"
    expected_key = os.getenv('CONTAINER_API_KEY') or os.getenv('API_SECRET_KEY')
    if not expected_key:
        logger.warning("服务器未配置 API Key")
        return False, "服务器未配置 API Key"
    if api_key != expected_key:
        logger.warning(f"API Key 不匹配")
        return False, "API Key 不匹配"
    return True, None

@app.route('/api/internal/publish', methods=['POST'])
def publish_task():
    """发布任务（内部接口 - 支持签名认证或API Key认证）"""
    api_key = request.headers.get('X-API-Key')
    if api_key:
        is_valid, error_msg = _validate_api_key()
        if not is_valid:
            return fail(code=401, message=error_msg)

    data = request.get_json(force=True, silent=True) or {}

    # 数据完整性校验（_checksum）
    input_checksum = data.pop('_checksum', None)
    if input_checksum:
        actual_checksum = DataIntegrity.calculate_hash(data)
        if actual_checksum != input_checksum:
            logger.warning(f"数据完整性校验失败: 期望{input_checksum[:8]}, 实际{actual_checksum[:8]}")
            return fail(code=401, message='数据完整性校验失败（数据可能被篡改）')

    task_type = data.get('task_type', 'report')
    title = data.get('title', '任务')
    content = data.get('content', {})
    operator_id = data.get('operator_id')
    priority = data.get('priority', 'normal')
    related_order = data.get('related_order')
    related_process = data.get('related_process')
    source = data.get('source', '')

    # 数据边界校验（服务端权威校验）
    is_valid, error_msg = global_data_boundary.validate_report_request(
        order_no=related_order or '',
        process=related_process or '',
        quantity=content.get('quantity', 0) if isinstance(content, dict) else 0,
        user_id=operator_id or ''
    )
    if not is_valid:
        logger.warning(f"发布任务数据校验失败: {error_msg}")
        return fail(code=400, message=error_msg)

    # 如果来自主软件订单管理，使用默认操作员进行分发
    if source == '主软件_订单管理':
        operator_id = operator_id or 'OP001'
        logger.info(f"订单任务来自主软件_订单管理，使用默认负责人: {operator_id}")

    try:
        pkg = container_center.collector.collect(
            data_type=task_type,
            title=title,
            content=content,
            operator_id=operator_id,
            priority=priority,
            related_order=related_order,
            related_process=related_process
        )

        # 如果没有指定负责人（来自主软件订单管理），不自动派单，等待调度中心手动派单
        if operator_id:
            container_center.distributor.distribute(pkg.id)

        if _server_audit_logger:
            try:
                _server_audit_logger.log(
                    action='task_publish',
                    operator=operator_id or 'system',
                    resource=f'task/{pkg.id}',
                    detail={'task_type': task_type, 'title': title}
                )
            except Exception as e:
                logger.warning(f"审计日志记录失败 (task_publish): {e}")

        return success(data={
            'task_id': pkg.id,
            'message': '任务已发布并分发'
        })
    except Exception as e:
        logger.exception(f"发布任务失败: {e}")
        return fail(code=500, message=f'发布失败: {str(e)}')


# ──────────────────────────────────────────────
# 配置版本管理API
# ──────────────────────────────────────────────

@app.route('/api/internal/config/deploy', methods=['POST'])
@require_signature
def deploy_config():
    """
    部署配置（内部接口 - 需要API签名认证）

    请求体:
        config_name: 配置名称
        config_data: 配置数据
    """
    data = request.get_json(force=True, silent=True) or {}
    config_name = data.get('config_name')
    config_data = data.get('config_data')
    timestamp = data.get('timestamp', time.strftime('%Y-%m-%dT%H:%M:%S'))

    if not config_name or config_data is None:
        return fail(code=400, message='缺少 config_name 或 config_data')

    version = datetime.now().strftime('%Y%m%d%H%M%S')

    entry = {
        'version': version,
        'config_name': config_name,
        'config_data': config_data,
        'deployed_at': timestamp,
        'created_at': time.strftime('%Y-%m-%d %H:%M:%S')
    }

    versions = _load_config_versions()
    if config_name not in versions:
        versions[config_name] = []
    versions[config_name].append(entry)

    max_versions = int(os.getenv('CONFIG_MAX_VERSIONS', '20'))
    if len(versions[config_name]) > max_versions:
        versions[config_name] = versions[config_name][-max_versions:]

    _save_config_versions(versions)

    logger.info(f"配置已部署: {config_name} (版本: {version})")
    return success(data={'config_name': config_name, 'version': version})


@app.route('/api/internal/config/versions/<config_name>', methods=['GET'])
def get_config_versions(config_name):
    """
    获取配置版本列表

    Args:
        config_name: 配置名称
    """
    versions = _load_config_versions()
    config_versions = versions.get(config_name, [])

    return success(data={
        'config_name': config_name,
        'versions': config_versions,
        'total': len(config_versions)
    })


@app.route('/api/internal/config/rollback', methods=['POST'])
@require_signature
def rollback_config():
    """
    回滚配置（内部接口 - 需要API签名认证）

    请求体:
        config_name: 配置名称
        version: 目标版本号
    """
    data = request.get_json(force=True, silent=True) or {}
    config_name = data.get('config_name')
    target_version = data.get('version')

    if not config_name or not target_version:
        return fail(code=400, message='缺少 config_name 或 version')

    versions = _load_config_versions()
    config_versions = versions.get(config_name, [])

    target = next((v for v in config_versions if v['version'] == target_version), None)
    if not target:
        return fail(code=404, message=f'版本 {target_version} 不存在')

    logger.info(f"配置已回滚: {config_name} -> 版本 {target_version}")
    return success(data={
        'config_name': config_name,
        'version': target_version,
        'config_data': target.get('config_data')
    })


# ──────────────────────────────────────────────
# 外协管理 API
# ──────────────────────────────────────────────

def _get_outsource_records(status: str = None) -> list:
    """获取外协记录列表"""
    pkg_dicts = container_center.storage.get_packages(limit=2000) or []
    return [p for p in pkg_dicts if p.get('data_type') == 'outsource'
            and (status is None or p.get('status') == status)]


def _update_outsource_extra(record_id: str, status: str, **extra) -> Optional[Dict]:
    """更新外协记录额外字段"""
    pkg_dicts = container_center.storage.get_packages(limit=2000) or []
    target = next((p for p in pkg_dicts if p.get('id') == record_id and p.get('data_type') == 'outsource'), None)
    if not target:
        return None
    content = target.get('content', {})
    if isinstance(content, str):
        import json as _json
        content = _json.loads(content)
    content.update(extra)
    container_center.storage.update_package(record_id, {'content': content, 'status': status})
    return target


@app.route('/api/outsource/records', methods=['GET'])
def list_outsource_records():
    """获取外协记录列表"""
    status = request.args.get('status')
    records = _get_outsource_records(status)
    records.sort(key=lambda r: r.get('created_at', ''), reverse=True)
    return success(data=records)


@app.route('/api/outsource/records/<record_id>', methods=['GET'])
def get_outsource_record(record_id):
    """获取单条外协记录"""
    pkg_dicts = container_center.storage.get_packages(limit=2000) or []
    target = next((p for p in pkg_dicts if p.get('id') == record_id and p.get('data_type') == 'outsource'), None)
    if not target:
        return fail(code=404, message='记录不存在')
    return success(data=target)


@app.route('/api/internal/outsource/publish', methods=['POST'])
@require_signature
def publish_outsource_task():
    """发布外协任务（内部接口 - 需要API签名认证）"""
    data = request.get_json(force=True, silent=True) or {}

    input_checksum = data.pop('_checksum', None)
    if input_checksum:
        actual_checksum = DataIntegrity.calculate_hash(data)
        if actual_checksum != input_checksum:
            logger.warning(f"外协数据完整性校验失败: 期望{input_checksum[:8]}, 实际{actual_checksum[:8]}")
            return fail(code=401, message='数据完整性校验失败')

    order_no = data.get('order_no', '').strip()
    process_name = data.get('process_name', '').strip()
    process_seq = data.get('process_seq', 1)
    planned_qty = data.get('planned_qty', 0)
    outsource_remark = data.get('outsource_remark', '').strip()
    operator_id = data.get('operator_id', '').strip()

    if not order_no or not process_name:
        return fail(code=400, message='工单号和工序名不能为空')

    is_valid, error_msg = global_data_boundary.validate_report_request(
        order_no=order_no,
        process=process_name,
        quantity=planned_qty,
        user_id=operator_id
    )
    if not is_valid:
        logger.warning(f"外协任务数据校验失败: {error_msg}")
        return fail(code=400, message=error_msg)

    try:
        pkg = container_center.collect_outsource(
            order_no=order_no,
            process_name=process_name,
            process_seq=process_seq,
            planned_qty=planned_qty,
            outsource_remark=outsource_remark,
            operator_id=operator_id
        )
        container_center.distributor.distribute(pkg.id)

        if _server_audit_logger:
            try:
                _server_audit_logger.log(
                    action='outsource_publish',
                    operator=operator_id or 'system',
                    resource=f'outsource/{pkg.id}',
                    detail={'order_no': order_no, 'process': process_name, 'qty': planned_qty}
                )
            except Exception as e:
                logger.warning(f"审计日志记录失败 (outsource_publish): {e}")

        return success(data={'id': pkg.id, 'message': '外协任务已发布并分发'})
    except Exception as e:
        logger.exception(f"发布外协任务失败: {e}")
        return fail(code=500, message=f'发布失败: {str(e)}')


@app.route('/api/outsource/records/<record_id>/feedback', methods=['POST'])
def feedback_outsource_record(record_id):
    """外协反馈（承诺天数）"""
    body = request.get_json(force=True, silent=True) or {}
    promised_days = body.get('promised_days')
    if promised_days is None:
        return fail(code=400, message='承诺天数不能为空')
    promised_days = int(promised_days)
    promised_date = (datetime.now() + timedelta(days=promised_days)).strftime('%Y-%m-%d %H:%M:%S')
    result = _update_outsource_extra(record_id, 'processing',
        promised_days=promised_days,
        promised_date=promised_date,
        feedback_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    )
    if not result:
        return fail(code=404, message='记录不存在')
    return success(message=f'已反馈：承诺 {promised_days} 天后完成')


@app.route('/api/outsource/records/<record_id>/complete', methods=['POST'])
def complete_outsource_record(record_id):
    """完成外协任务"""
    result = _update_outsource_extra(record_id, 'completed',
        completed_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    )
    if not result:
        return fail(code=404, message='记录不存在')

    if _server_audit_logger:
        try:
            _server_audit_logger.log(
                action='outsource_complete',
                operator='system',
                resource=f'outsource/{record_id}',
                detail={'status': 'completed'}
            )
        except Exception as e:
            logger.warning(f"审计日志记录失败 (outsource_complete): {e}")

    return success(message='外协任务已完成')


@app.route('/api/outsource/records/<record_id>/receive', methods=['POST'])
def receive_outsource_record(record_id):
    """外协收货确认"""
    result = _update_outsource_extra(record_id, 'received',
        received_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    )
    if not result:
        return fail(code=404, message='记录不存在')

    if _server_audit_logger:
        try:
            _server_audit_logger.log(
                action='outsource_receive',
                operator='system',
                resource=f'outsource/{record_id}',
                detail={'status': 'received'}
            )
        except Exception as e:
            logger.warning(f"审计日志记录失败 (outsource_receive): {e}")

    return success(message='已确认收货入库')


@app.route('/api/outsource/config', methods=['GET'])
def get_outsource_config():
    """获取外协配置"""
    from container_config import container_config as cc_cfg
    cfg = cc_cfg.get_outsourc_config()
    return success(data={
        'enabled': cfg.enabled,
        'default_operator_id': cfg.default_operator_id,
        'remind_days': cfg.remind_days,
        'overdue_remind_times': cfg.overdue_remind_times,
    })


@app.route('/api/outsource/config', methods=['POST'])
def update_outsource_config():
    """更新外协配置"""
    body = request.get_json(force=True, silent=True) or {}
    from container_config import container_config as cc_cfg
    cc_cfg.update_outsourc_config(**body)
    return success(message='配置已更新')


if __name__ == '__main__':
    # 启动桌面端回调管理器
    if desktop_callback_manager:
        desktop_callback_manager.start()

    print('=' * 60)
    print('  容器中心API服务器启动')
    print('=' * 60)
    print('  服务地址: http://localhost:5002')
    print()
    print('  API签名验证:', '已启用' if api_secret_key else '未启用（危险）')
    print('  健康检查器:', '[OK]' if _server_health_checker else '[--]')
    print('  部署管理器:', '[OK]' if _server_deployment_manager else '[--]')
    print('  审计日志:', '[OK]' if _server_audit_logger else '[--]')
    print('  增强备份:', '[OK]' if _server_backup_manager else '[--]')
    print('  数据边界校验:', '[OK]')
    print('  外协管理:', '[OK]')
    print()

    app.run(host='0.0.0.0', port=Config.CONTAINER_CENTER_PORT, debug=False)
