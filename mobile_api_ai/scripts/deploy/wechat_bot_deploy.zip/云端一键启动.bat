@echo off
chcp 65001 >nul
title 云端服务一键启动
setlocal enabledelayedexpansion

set "ROOT_DIR=%~dp0"

echo ╔═══════════════════════════════════════════╗
echo ║       云端服务一键启动                    ║
echo ║       不锈钢网带跟单系统                  ║
echo ╚═══════════════════════════════════════════╝
echo.

REM 检查Python环境
python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] Python 未安装或未加入环境变量
    echo 请安装 Python 3.8+ 并确保添加到 PATH
    pause
    exit /b 1
)

for /f "tokens=1,2*" %%i in ('python --version 2^>^&1') do set PY_VER=%%j
echo [Python] %PY_VER%
echo.

cd /d "%ROOT_DIR%"

REM ─── 1. 容器中心 ────────────────────────────────
echo [1/3] 启动容器中心（端口 5002）...
netstat -ano | findstr ":5002 " | findstr "LISTENING" >nul 2>&1
if errorlevel 1 (
    start "容器中心:5002" cmd /c "python container_center_api.py"
    echo   └─ [启动中] 容器中心 ^(端口 5002^)
) else (
    echo   └─ [已运行] 端口 5002 已有服务在监听
)

REM ─── 2. 微信服务主站 ────────────────────────────
echo [2/3] 启动微信服务主站（端口 5003）...
netstat -ano | findstr ":5003 " | findstr "LISTENING" >nul 2>&1
if errorlevel 1 (
    start "微信服务:5003" cmd /c "python wechat_server.py --port 5003"
    echo   └─ [启动中] 微信服务主站 ^(端口 5003^)
) else (
    echo   └─ [已运行] 端口 5003 已有服务在监听
)

REM ─── 3. 云端辅助服务 ────────────────────────────
echo [3/3] 启动云端辅助服务（端口 5006）...
netstat -ano | findstr ":5006 " | findstr "LISTENING" >nul 2>&1
if errorlevel 1 (
    start "云端服务:5006" cmd /c "set FLASK_PORT=5006 && python wechat_cloud.py"
    echo   └─ [启动中] 云端辅助服务 ^(端口 5006^)
) else (
    echo   └─ [已运行] 端口 5006 已有服务在监听
)

echo.

REM ─── 等待启动 ──────────────────────────────────
echo  等待服务启动...
set "WAIT_SECONDS=8"
for /l %%i in (1,1,%WAIT_SECONDS%) do (
    ping -n 2 127.0.0.1 >nul
)

REM ─── 校验端口 ──────────────────────────────────
echo.
echo ════════════════════════════════════════════
echo  端口状态检查
echo ════════════════════════════════════════════

set "ALL_OK=1"
for %%p in (5002 5003 5006) do (
    netstat -ano | findstr ":%%p " | findstr "LISTENING" >nul
    if errorlevel 1 (
        echo  [端口 %%p]  ✗ 未监听到服务
        set "ALL_OK=0"
    ) else (
        echo  [端口 %%p]  ✓ 服务运行中
    )
)

echo.

if "!ALL_OK!"=="1" (
    echo ╔═══════════════════════════════════════════╗
    echo ║          所有服务启动成功！               ║
    echo ╚═══════════════════════════════════════════╝
) else (
    echo ╔═══════════════════════════════════════════╗
    echo ║       部分服务未启动，请检查日志          ║
    echo ╚═══════════════════════════════════════════╝
)

echo.
echo  访问地址:
echo   容器中心:   http://localhost:5002
echo   微信服务:   http://localhost:5003
echo   云端服务:   http://localhost:5006
echo.
echo  健康检查:
echo   微信服务:   http://localhost:5003/health
echo.
echo  停止服务:   双击 stop_all.bat
echo.

pause
