@echo off
chcp 65001 >nul
echo ============================================
echo  云端微信服务启动脚本
echo ============================================
echo.

:: 切换到脚本所在目录
pushd "%~dp0"

:: 设置端口环境变量
set FLASK_PORT=5006

:: 检查Python是否可用
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ Python 未安装或未加入环境变量
    echo 请安装 Python 3.8+ 并确保添加到 PATH
    pause
    popd
    exit /b 1
)

:: 启动服务
echo 正在启动云端微信服务...
echo 端口: %FLASK_PORT%
echo.
python wechat_cloud.py

:: 如果服务意外退出，暂停显示错误
if %errorlevel% neq 0 (
    echo.
    echo ❌ 服务启动失败！
    pause
)

popd